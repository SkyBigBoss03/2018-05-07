package com.jt.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jt.common.vo.EasyUIResult;
import com.jt.manage.mapper.ItemMapper;
import com.jt.manage.pojo.Item;

@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	private ItemMapper itemMapper;
	
	/**
	 * 1.获取记录总数  2.查询分页数据
	 * 
	 *  select * from tb_item limit 0,20
		select * from tb_item limit 20,20
		select * from tb_item limit 40,20
		
		第N页
		select * from tb_item limit (page-1) * rows,20
	 * 
	 */
	@Override
	public EasyUIResult findItemByPage(Integer page, Integer rows) {
		//查询记录总数
		int total = itemMapper.findItemConunt();
		
		int start = (page - 1) * rows;
		
		List<Item> itemList = itemMapper.findItemList(start,rows);
		
		return new EasyUIResult(total, itemList);
	}

	@Override
	public String findItemCatName(Long itemCatId) {
		
		return itemMapper.findItemCatById(itemCatId);
	}
	
	
}
