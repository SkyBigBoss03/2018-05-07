package com.jt.manage.service;

import com.jt.common.vo.EasyUIResult;

public interface ItemService {

	EasyUIResult findItemByPage(Integer page, Integer rows);

	String findItemCatName(Long itemCatId);

}
